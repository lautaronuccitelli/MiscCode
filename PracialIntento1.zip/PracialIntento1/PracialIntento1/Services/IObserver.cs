namespace Services;

using Models;

public interface IObserver
{
    
}