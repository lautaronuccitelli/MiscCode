namespace Controllers;

using Builders;
using Data;
using Models;
using Services;
using Strategy;

public class PedidoController()
{
    private readonly IRepositorio<Pedido> _repositorio;
    private readonly PedidoService _pedidoService;
    private readonly IPedidoBuilder _pedidoBuilder;
    private IEnvioStrategy _currentStrategy;

    public PedidoController(IRepositorio<Pedido> repositorio, PedidoService pedidoService) : this()
    {
        _repositorio = repositorio;
        _pedidoService = pedidoService;
        _pedidoBuilder = new PedidoBuilder();
        _currentStrategy = new RetiroStrategy();
        
        _pedidoBuilder.AplicarEnvio(_currentStrategy);
    }

    public void AgregarProducto(string nombre, decimal precio, int cantidad)
    {
        if (precio <= 0 || cantidad <= 0)
        {
            msg("El precio y la cantidad deben ser mayores a 0.", ConsoleColor.Red);
            return; 
        }

        var producto = new Producto { Nombre = nombre, Precio = precio, Cantidad = cantidad };
        _pedidoBuilder.AgregarProducto(producto);
        msg("Producto agregado correctamente.", ConsoleColor.Green);
    }
    public void msg(string texto, ConsoleColor color = ConsoleColor.White)
    {
        Console.ForegroundColor = color;
        Console.WriteLine(texto);
        Console.ResetColor();
    }

    public void SeleccionarEnvio(IEnvioStrategy envioStrategy)
    {
        _currentStrategy = envioStrategy;
        _pedidoBuilder.AplicarEnvio(_currentStrategy);
        msg("El envio se cambio a:" + _currentStrategy.GetType().Name.Replace("Strategy", ""), ConsoleColor.Green);
    }

    public void ConfirmarPedido(string cliente, string direccion)
    {
        if(string.IsNullOrEmpty(cliente) || string.IsNullOrEmpty(direccion))
        {
            msg("El cliente y la direccion no pueden ser nulos.", ConsoleColor.Red);
            return;
        }

        _pedidoBuilder.ConCliente(cliente);
        _pedidoBuilder.ConDireccion(direccion);

        Pedido pedidoFinal;
        try
        {
            pedidoFinal = _pedidoBuilder.Build();
        }
        catch (Exception e)
        {
            msg("Error creando el pedido.", ConsoleColor.Red);
            return;
        }
        _repositorio.Guardar(pedidoFinal);
        _pedidoService.Confirmar(pedidoFinal);
        
        msg("Pedido Confirmado", ConsoleColor.Green);
        msg("Precio Final: " + pedidoFinal.Total, ConsoleColor.Green);
        msg("Tipo de envio: " + pedidoFinal.TipoEnvio, ConsoleColor.Green);
        msg("Direccion de envio: " + pedidoFinal.Direccion, ConsoleColor.Green);
        msg("Cliente: " + pedidoFinal.Cliente, ConsoleColor.Green);
        msg("Productos: ", ConsoleColor.Green);
        pedidoFinal.Productos.ForEach(p => msg(p.Nombre + " - " + p.Cantidad + " x " + p.Precio, ConsoleColor.Green));
        
    }
    public List<Pedido> ListarPedidosConfirmados()
    {
        return _repositorio.ObtenerTodos();
    }
}