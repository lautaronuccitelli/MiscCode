﻿using Controllers;
using Data;
using Models;
using Services;
using Strategy;

class Program
{
    static void Main()
    {
        var clienteObs = new ClienteObserver();
        var logisticaObs = new LogisticaObserver();

        var repo = new RepositorioJson();
        var pedidoService = new PedidoService();
        var controller = new PedidoController(repo, pedidoService);
        
        bool continuar = true;
        do
        {
            Console.Clear();
            MostrarMenu();
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    AgregarProducto(controller);
                    break;
                case "2":
                    SeleccionarEnvio(controller);
                    break;
                case "3":
                    ConfirmarPedido(controller);
                    break;                
                case "4":
                    ListarPedidos(controller);
                    break;
                case "5":
                    continuar = false;
                    Console.WriteLine("Saliendo del sistema...");
                    break;
                default:
                    Console.WriteLine("Opción no válida. Intente de nuevo.");
                    break;
            }
            if (continuar)
            {
                Console.WriteLine("\nPresione ENTER para continuar...");
                Console.ReadLine();
            }

        } while (continuar);
    }

    private static void MostrarMenu()
    {
        Console.WriteLine("\n--- SISTEMA DE PEDIDOS (IDRA) ---");
        Console.WriteLine("1. Agregar Producto al Pedido");
        Console.WriteLine("2. Seleccionar Estrategia de Envío");
        Console.WriteLine("3. Confirmar Pedido");
        Console.WriteLine("4. Listar");
        Console.WriteLine("5. Salir");
        Console.Write("Seleccione una opción: ");
    }
    
    private static void ListarPedidos(PedidoController controller)
    {
        var pedidos = controller.ListarPedidosConfirmados();
        Console.WriteLine("\nPedidos Confirmados:");
        foreach (var p in pedidos)
        {
            Console.WriteLine($"-----------------------------------");
            Console.WriteLine($" Cliente: {p.Cliente} ({p.Direccion})");
            Console.WriteLine($" Envío: {p.TipoEnvio} (${p.CostoEnvio:F2})");
            Console.WriteLine($" TOTAL: ${p.Total:F2}");
        }
    }
    
    private static void AgregarProducto(PedidoController controller)
    {
        Console.WriteLine("\nAgregar Producto al Pedido");
        Console.Write("Nombre del producto: ");
        string nombre = Console.ReadLine();
        Console.Write("Precio del producto: ");
        decimal precio = decimal.Parse(Console.ReadLine());
        Console.Write("Cantidad del producto: ");
        int cantidad = int.Parse(Console.ReadLine());
    }

    private static void SeleccionarEnvio(PedidoController controller)
    {
        Console.WriteLine("1. Moto.");
        Console.WriteLine("2. Correo.");
        Console.WriteLine("3. Retiro en el local.");
        Console.WriteLine("Seleccione una opcion: ");
        string opcion = Console.ReadLine();
        
        IEnvioStrategy envioStrategy;
        switch (opcion)
        {
            case "1":
                envioStrategy = new MotoStrategy();
                break;
            case "2":
                envioStrategy = new CorreoStrategy();
                break;
            case "3":
                envioStrategy = new RetiroStrategy();
                break;
            default:
                Console.WriteLine("Opción no válida. Se mantiene 'Retiro en Local'.");
                return;
        }
        controller.SeleccionarEnvio(envioStrategy);
    }

    private static void ConfirmarPedido(PedidoController controller)
    {
        Console.Write("\nIngrese Nombre del Cliente: ");
        string cliente = Console.ReadLine();
        Console.Write("Ingrese Dirección de Envío: ");
        string direccion = Console.ReadLine();

        try
        {
            controller.ConfirmarPedido(cliente, direccion);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
    }
}
