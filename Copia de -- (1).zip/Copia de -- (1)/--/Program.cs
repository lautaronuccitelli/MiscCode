﻿using System;
using System.Collections.Generic;
using PatronesDeDiseno.Singleton;
using PatronesDeDiseno.Builder.Interfaces;
using PatronesDeDiseno.Builder.Models;
using PatronesDeDiseno.Builder.Builders;
using PatronesDeDiseno.Builder.Services;
using PatronesDeDiseno.AbstractFactory.Interfaces;
using PatronesDeDiseno.AbstractFactory.GoogleMaps;
using PatronesDeDiseno.AbstractFactory.OpenStreetMap;
using PatronesDeDiseno.AbstractFactory.Services;
using PatronesDeDiseno.Adapter.Services;
using PatronesDeDiseno.Command;
using PatronesDeDiseno.Command.Comandos_Concretos;
using PatronesDeDiseno.Command.Invoker;
using PatronesDeDiseno.Decorator.Services;
using PatronesDeDiseno.Facade;
using PatronesDeDiseno.Strategy;
using PatronesDeDiseno.Strategy.EstrategiasConcretas;
using PatronesDeDiseno.Strategy.Contexto;
using PatronesDeDiseno.Observer.Observadores;
using PatronesDeDiseno.Observer;
using PatronesDeDiseno.Command.Receiver;
using PatronesDeDiseno.Facade.Facades;

namespace PatronesDeDiseno
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcion = 0;
            while (opcion != 10)
            {
                Console.Clear();
                Console.WriteLine("=== PATRONES DE DISENO ===");
                Console.WriteLine("1) SINGLETON - Logger");
                Console.WriteLine("2) BUILDER - Construccion de Hamburguesas");
                Console.WriteLine("3) ABSTRACT FACTORY - Navegador de Mapas");
                Console.WriteLine("4) ADAPTER - Sistema de Impresion");
                Console.WriteLine("5) DECORATOR - Sistema de Mensajeria");
                Console.WriteLine("6) FACADE - Gestion de Usuarios");
                Console.WriteLine("7) STRATEGY - Gestion E-Commerce");
                Console.WriteLine("8) OBSERVER - Gestion Pedidos");
                Console.WriteLine("9) COMMAND - Gestion de Carrito");
                Console.WriteLine("10) SALIR");
                Console.Write("Elige una opcion (1-7): ");

                if (int.TryParse(Console.ReadLine(), out opcion))
                {
                    switch (opcion)
                    {
                        case 1:
                            EjecutarSingleton();
                            break;
                        case 2:
                            EjecutarBuilder();
                            break;
                        case 3:
                            EjecutarAbstractFactory();
                            break;
                        case 4:
                            EjecutarAdapter();
                            break;
                        case 5:
                            EjecutarDecorator();
                            break;
                        case 6:
                            EjecutarFacade();
                            break;
                        case 7:
                            EjecutarStrategy();
                            break;
                        case 8:
                            EjecutarObserver();
                            break;
                        case 9:
                            EjecutarCommand();
                            break;
                        case 10:
                            Console.WriteLine("Hasta luego!");
                            return;
                        default:
                            Console.WriteLine("Opcion invalida. Presiona cualquier tecla para continuar...");
                            Console.ReadKey();
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Por favor ingresa un numero valido.");
                    Console.ReadKey();
                }
            }
        }

        #region SINGLETON - LOGGER
        static void EjecutarSingleton()
        {
            Console.Clear();
            Console.WriteLine("=== PRUEBA DEL LOGGER SINGLETON ===");

            var a = Logger.Instancia;
            Console.WriteLine("Primera referencia obtenida (variable 'a')");

            a.Info("Aplicacion iniciada");
            a.Info("Usuario logueado correctamente");
            a.Info("Procesando datos importantes");
            a.Info("Operacion completada exitosamente");

            Console.WriteLine($"Total de mensajes registrados: {a.TotalMensajes}");

            var b = Logger.Instancia;
            Console.WriteLine("Segunda referencia obtenida (variable 'b')");

            b.Info("Nuevo proceso iniciado");
            b.Info("Guardando configuracion");
            
            b.Dump();

            bool sonElMismoObjeto = ReferenceEquals(a, b);
            Console.WriteLine($"Las variables 'a' y 'b' referencian al mismo objeto: {sonElMismoObjeto}");
            

            Logger.Instancia.Dump();
            Console.WriteLine($"Total de mensajes registrados: {b.TotalMensajes}");

            Console.WriteLine("Presiona cualquier tecla para volver al menu principal...");
            Console.ReadKey();
        }


        
        #endregion

        #region BUILDER - HAMBURGUESAS
        static void EjecutarBuilder()
        {
            int opcionBuilder = 0;
            while (opcionBuilder != 5)
            {
                //Console.Clear();
                Console.WriteLine("=== CONSTRUCCION DE HAMBURGUESAS (BUILDER) ===");
                Console.WriteLine("1) HAMBURGUESA CLASICA (usando Cocinero)");
                Console.WriteLine("2) HAMBURGUESA DOBLE CHEDDAR (usando Cocinero)");
                Console.WriteLine("3) HACER HAMBURGUESA PERSONALIZADA (manual)");
                Console.WriteLine("5) VOLVER AL MENU PRINCIPAL");
                Console.Write("Elige una opcion (1-5): ");

                if (int.TryParse(Console.ReadLine(), out opcionBuilder))
                {
                    switch (opcionBuilder)
                    {
                        case 1:
                            CrearClasica();
                            break;
                        case 2:
                            CrearDobleCheddar();
                            break;
                        case 3:
                            CrearManual();
                            break;
                        case 5:
                            return;
                        default:
                            Console.WriteLine("Opcion invalida. Presiona una tecla para continuar...");
                            Console.ReadKey();
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Por favor ingresa un numero valido.");
                    Console.ReadKey();
                }
            }
        }

        static void CrearClasica()
        {
            var builder = new HamburguesaClasicaBuilder();
            var h = Cocinero.Clasica(builder);
            Console.WriteLine(h);
        }

        static void CrearDobleCheddar()
        {
            var builder = new HamburguesaClasicaBuilder();
            var h = Cocinero.DobleCheddar(builder);
            Console.WriteLine(h);
        }


        static void CrearManual()
        {
            var builder = new HamburguesaClasicaBuilder();
            Console.WriteLine();
            Console.WriteLine("--- Hamburguesa personalizada ---");

            Console.Write("Pan (ej: Pan integral): ");
            var pan = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(pan)) builder.ConPan(pan);

            Console.Write("Carne (ej: Pollo / Vacuna): ");
            var carne = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(carne)) builder.ConCarne(carne);

            if (AskYesNo("Queso? (s/n): ")) builder.ConQueso();
            else builder.ConQueso(false);

            if (AskYesNo("Lechuga? (s/n): ")) builder.ConLechuga();
            if (AskYesNo("Tomate? (s/n): ")) builder.ConTomate();
            if (AskYesNo("Cebolla? (s/n): ")) builder.ConCebolla();

            Console.Write("Salsa (enter para nada): ");
            var salsa = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(salsa)) builder.ConSalsa(salsa);

            try
            {
                var h = builder.Build();
                Console.WriteLine();
                Console.WriteLine("--- Resultado ---");
                Console.WriteLine(h);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"ERROR: {ex.Message}");
            }

            Console.WriteLine("Presiona cualquier tecla para volver al menu...");
            Console.ReadKey();
        }
        

        static bool AskYesNo(string prompt)
        {
            bool respuestaValida = false;
    
            while (!respuestaValida)
            {
                Console.Write(prompt);
                var r = Console.ReadLine()?.Trim().ToLower();
        
                if (string.IsNullOrEmpty(r)) return false;
                if (r == "s" || r == "si" || r == "y" || r == "yes") return true;
                if (r == "n" || r == "no") return false;
        
                Console.WriteLine("Respuesta no valida. Responde 's' o 'n'.");
            }
    
            return false;
        }
        #endregion

        #region ABSTRACT FACTORY - NAVEGADOR
        static void EjecutarAbstractFactory()
        {
            Console.Clear();
            Console.WriteLine("=== NAVEGADOR DE MAPAS (ABSTRACT FACTORY) ===");
            Console.WriteLine("1) Usar Google Maps");
            Console.WriteLine("2) Usar OpenStreetMap");
            Console.Write("Elige el proveedor de mapas (1-2): ");

            if (int.TryParse(Console.ReadLine(), out int opcion))
            {
                IMapServiceFactory factory = null;

                switch (opcion)
                {
                    case 1:
                        factory = new GoogleMapServicesFactory();
                        Console.WriteLine("Has seleccionado Google Maps");
                        break;
                    case 2:
                        factory = new OpenStreetMapServicesFactory();
                        Console.WriteLine("Has seleccionado OpenStreetMap");
                        break;
                    default:
                        Console.WriteLine("Opcion invalida, usando Google Maps por defecto");
                        factory = new GoogleMapServicesFactory();
                        break;
                }

                Console.Write("Ingresa la ubicacion a mostrar: ");
                var ubicacion = Console.ReadLine() ?? "Buenos Aires";

                Console.Write("Ingresa la direccion a buscar: ");
                var direccion = Console.ReadLine() ?? "Av. Corrientes 1000";

                var navegador = new Navegador(factory);
                Console.WriteLine();
                Console.WriteLine("=== EJECUTANDO NAVEGADOR ===");
                navegador.Run(ubicacion, direccion);
            }
            else
            {
                Console.WriteLine("Entrada invalida, usando configuracion por defecto");
                var factory = new GoogleMapServicesFactory();
                var navegador = new Navegador(factory);
                navegador.Run("Mar del Plata", "Plaza San Martin");
            }

            Console.WriteLine("Presiona cualquier tecla para volver al menu principal...");
            Console.ReadKey();
        }
        #endregion

        #region ADAPTER - IMPRESION
        static void EjecutarAdapter()
        {
            Console.Clear();
            Console.WriteLine("=== SISTEMA DE IMPRESION (ADAPTER) ===");

            var sistema = new SistemaImpresion();
            sistema.DemostrarPatron();

            Console.WriteLine("Presiona cualquier tecla para volver al menu principal...");
            Console.ReadKey();
        }
        #endregion

        #region DECORATOR - MENSAJERIA
        static void EjecutarDecorator()
        {
            Console.Clear();
            Console.WriteLine("=== SISTEMA DE MENSAJERIA (DECORATOR) ===");

            var sistema = new SistemaMensajeria();
            sistema.DemostrarPatron();

            Console.WriteLine("Presiona cualquier tecla para volver al menu principal...");
            Console.ReadKey();
        }
        #endregion

        #region FACADE - USUARIOS
        static void EjecutarFacade()
        {
            Console.Clear();
            Console.WriteLine("=== GESTION DE USUARIOS (FACADE) ===");
            Console.WriteLine();

            var userFacade = new UserFacade();

            int opcion = 0;
            while (opcion != 3)
            {
                Console.WriteLine("1. Registrar usuario");
                Console.WriteLine("2. Volver al menu principal");
                Console.Write("Selecciona una opcion: ");

                opcion = int.Parse(Console.ReadLine());

                if (opcion == 1)
                {
                    Console.WriteLine();
                    Console.Write("Ingresa el nombre: ");
                    var nombre = Console.ReadLine();

                    Console.Write("Ingresa el email: ");
                    var email = Console.ReadLine();

                    Console.WriteLine();
                    Console.WriteLine("--- Iniciando proceso de registro ---");
            
                    bool resultado = userFacade.RegistrarUsuario(nombre, email);
            
                    Console.WriteLine();
                    if (resultado)
                    {
                        Console.WriteLine("Usuario registrado exitosamente!");
                    }
                    else
                    {
                        Console.WriteLine("Error al registrar usuario");
                    }
            
                    Console.WriteLine();
                    Console.WriteLine("========================================");
                    Console.WriteLine();
                }
                else if (opcion == 2)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Opcion no valida. Intenta de nuevo.");
                    Console.WriteLine();
                }
            }
        }
        #endregion
        
        #region STRATEGY - PROMO

        static void EjecutarStrategy()
        {
            Console.Clear();
            Console.WriteLine("=== PRUEBA DEL STRATEGY ===");
            Console.WriteLine("Ingresa el subtotal.");
            decimal subtotal = decimal.Parse(Console.ReadLine());
            var carrito = new Strategy.Contexto.Carrito(new SinDescuento());
            int opcion = 0;
            while (opcion != 6)
            {
                Console.Clear();
                Console.WriteLine("=== DESCUENTOS ===");
                Console.WriteLine($"Subtotal actual: ${subtotal}");
                Console.WriteLine($"Estrategia actual: {carrito._descuento.Nombre}");
                
                decimal total = carrito.Total(subtotal);
                Console.WriteLine($"TOTAL: ${total:F2}");
                Console.WriteLine();
                
                Console.WriteLine("1. Ingresar subtotal");
                Console.WriteLine("2. Sin Descuento");
                Console.WriteLine("3. Porcentaje");
                Console.WriteLine("4. Tope Banco");
                Console.WriteLine("6. Salir");
                Console.Write("Opción: ");
                
                opcion = int.Parse(Console.ReadLine());
                
                switch (opcion)
                {
                    case 1:
                        Console.Write("Subtotal: $");
                        subtotal = decimal.Parse(Console.ReadLine());
                        break;
                        
                    case 2:
                        carrito.SetDescuento(new SinDescuento());
                        break;
                        
                    case 3:
                        carrito.SetDescuento(new Porcentaje());
                        break;
                        
                    case 4:
                        carrito.SetDescuento(new TopeBanco());
                        break;
                        
                    /*case 5:
                        total = carrito.Total(subtotal);
                        Console.WriteLine($"Subtotal: ${subtotal:F2}");
                        Console.WriteLine($"Estrategia: {carrito._descuento.Nombre}");
                        Console.WriteLine($"TOTAL: ${total:F2}");
                        Console.WriteLine("Presiona cualquier tecla para continuar...");
                        Console.ReadKey();
                        break;*/
                        
                    case 6:
                        return;
                }
            } 
        }    
        #endregion
        
        #region OBSERVER - PEDIDOS

        static void EjecutarObserver()
        {
            var pedidoService = new PedidoService();
            var cliente = new NotificadorCliente();
            var logistica = new PanelLogistica();
            var auditoria = new AuditoriaPedidos();

            cliente.Suscribir(pedidoService);
            logistica.Suscribir(pedidoService);
            auditoria.Suscribir(pedidoService);

            pedidoService.CambiarEstado(101, EstadoPedido.Recibido);
        
            Console.WriteLine();
            pedidoService.CambiarEstado(101, EstadoPedido.Preparando);
        
            Console.WriteLine();
            pedidoService.CambiarEstado(101, EstadoPedido.Enviado);

            logistica.Desuscribir(pedidoService);

            Console.WriteLine();
            pedidoService.CambiarEstado(101, EstadoPedido.Entregado);
        }
        #endregion
        
        #region COMMAND - CARRITO
        public static void EjecutarCommand()
        {
            var carrito = new Command.Receiver.Carrito();
            var inv = new CarritoInvoker();
            
            Console.WriteLine("=== DEMO Command: Carrito con Undo/Redo ===");
            
            while (true)
            {
                Console.WriteLine("Opciones:");
                Console.WriteLine("1) Agregar item");
                Console.WriteLine("2) Quitar item");
                Console.WriteLine("3) Cambiar cantidad");
                Console.WriteLine("4) Undo");
                Console.WriteLine("5) Redo");
                Console.WriteLine("6) Total");
                Console.WriteLine("7) Promo (Macro)");
                Console.WriteLine("8) Salir");
                Console.Write("Opción: ");
                
                var opcion = Console.ReadLine();
                
                switch (opcion)
                {
                    case "1":
                        Console.Write("SKU: ");
                        var sku = Console.ReadLine();
                        Console.Write("Nombre: ");
                        var nombre = Console.ReadLine();
                        Console.Write("Precio: ");
                        var precio = decimal.Parse(Console.ReadLine() ?? "0");
                        Console.Write("Cantidad: ");
                        var cantidad = int.Parse(Console.ReadLine() ?? "0");
                        
                        inv.Run(new AgregarItemCommand(carrito, new Item(sku, nombre, precio, cantidad)));
                        Console.WriteLine($"Agregado: {nombre}");
                        break;
                        
                    case "2":
                        Console.Write("SKU a quitar: ");
                        var skuQuitar = Console.ReadLine();
                        inv.Run(new QuitarItemCommand(carrito, skuQuitar));
                        Console.WriteLine($"Quitado item: {skuQuitar}");
                        break;
                        
                    case "3":
                        Console.Write("SKU: ");
                        var skuCambiar = Console.ReadLine();
                        Console.Write("Nueva cantidad: ");
                        var nuevaCant = int.Parse(Console.ReadLine() ?? "0");
                        inv.Run(new CambiarCantidadCommand(carrito, skuCambiar, nuevaCant));
                        Console.WriteLine($"Cantidad cambiada para {skuCambiar}");
                        break;
                        
                    case "4":
                        inv.Undo();
                        Console.WriteLine("Undo ejecutado");
                        break;
                        
                    case "5":
                        inv.Redo();
                        Console.WriteLine("Redo ejecutado");
                        break;
                        
                    case "6":
                        Console.WriteLine("=== CARRITO ===");
                        carrito.MostrarItems();
                        Console.WriteLine($"Total: ${carrito.Total():F2}");
                        break;
                        
                    case "7":
                        var comandosPromo = new List<ICommand>
                        {
                            new AgregarItemCommand(carrito, new Item("PROMO1", "Producto Promo A", 10.00m, 2)),
                            new AgregarItemCommand(carrito, new Item("PROMO2", "Producto Promo B", 15.50m, 1)),
                            new CambiarCantidadCommand(carrito, "PROMO1", 3)
                        };
                        inv.Run(new MacroCommand(comandosPromo));
                        Console.WriteLine("Promo aplicada (3 acciones en una)");
                        break;
                        
                    case "8":
                        Console.WriteLine("=== Fin de la demo ===");
                        return;
                        
                    default:
                        Console.WriteLine("Opción inválida");
                        break;
                }
            }
        }
        #endregion
        
    }
}
