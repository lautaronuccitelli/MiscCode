package parkinglot;

public class Car {
    private String carModel;
    private String carPlate;
    private String phone;

    
    public Car (String carPlate, String phone, String carModel){
        this.carPlate = carPlate;
        this.phone = phone;
        this.carModel=carModel;
    }

    public String getCarPlate(){
        return carPlate;
    }
    public String getPhone(){
        return phone;
    }
    public String getCarModel(){
    return carModel;
    }

    public String toString(){
        return  carModel +  ", Plate = " + carPlate + ", Phone = " + phone + ". ";
    }
}
