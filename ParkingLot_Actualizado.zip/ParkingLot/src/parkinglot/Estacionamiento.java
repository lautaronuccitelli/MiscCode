package parkinglot;

public class Estacionamiento {

    public static void main(String[] args) {
        Car car1 = new Car("ABC 123","223412413411234", "Honda");
        Place Place1 = new Place("A1");

        Garage garage = new Garage(car1, Place1, "08:00");
        

        garage.getExit("17:00");
        System.out.println("Car Registered: " + garage);
    }
    
}
