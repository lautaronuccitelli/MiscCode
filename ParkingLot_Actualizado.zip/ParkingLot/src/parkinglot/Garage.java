
package parkinglot;


public class Garage {
    private Car car;
    private Place place;
    private String enter;
    private String exit;

    public Garage(Car car, Place place, String enter){
        this.car = car;
        this.place = place;
        this.enter = enter;
        
    }

    public void getExit(String exit){
          this.exit = exit;
    }

    public String toString(){
        return "Garage: Car = " + car + "Place: " + place + "Enter = " + enter + ", Exit = " + exit + ".";

    }
}
