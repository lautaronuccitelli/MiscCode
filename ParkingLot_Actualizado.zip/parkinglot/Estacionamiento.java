package parkinglot;

import java.util.Scanner;

public class Estacionamiento {
    public static void main(String[] args) {
        Garage garage = new Garage(10);
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- MENÚ ESTACIONAMIENTO ---");
            System.out.println("1. Ingresar vehículo");
            System.out.println("2. Retirar vehículo");
            System.out.println("3. Mostrar lugares libres");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.println("Tipo de vehículo (1=Auto, 2=Camioneta, 3=Moto, 4=Camión): ");
                    int tipo = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Ingrese patente: ");
                    String patente = scanner.nextLine();

                    Car vehiculo = null;

                    if (tipo == 1) {
                        vehiculo = new Car(patente);
                    } else if (tipo == 2) {
                        System.out.print("¿Tiene cúpula? (true/false): ");
                        boolean cupula = scanner.nextBoolean();
                        vehiculo = new Camioneta(patente, cupula);
                    } else if (tipo == 3) {
                        System.out.print("¿Tiene parabrisas? (true/false): ");
                        boolean parabrisas = scanner.nextBoolean();
                        vehiculo = new Moto(patente, parabrisas);
                    } else if (tipo == 4) {
                        System.out.print("Cantidad de ejes: ");
                        int ejes = scanner.nextInt();
                        vehiculo = new Camion(patente, ejes);
                    }

                    if (vehiculo != null) {
                        garage.ingresarVehiculo(vehiculo);
                    }
                    break;

                case 2:
                    System.out.print("Ingrese patente del vehículo a retirar: ");
                    String retiro = scanner.nextLine();
                    garage.retirarVehiculo(retiro);
                    break;

                case 3:
                    garage.mostrarLugaresLibres();
                    break;

                case 0:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción no válida.");
                    break;
            }

        } while (opcion != 0);

        scanner.close();
    }
}
