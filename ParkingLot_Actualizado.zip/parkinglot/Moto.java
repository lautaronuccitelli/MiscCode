package parkinglot;

public class Moto extends Car {
    private boolean tieneParabrisas;

    public Moto(String patente, boolean tieneParabrisas) {
        super(patente);
        this.tieneParabrisas = tieneParabrisas;
    }

    public boolean tieneParabrisas() {
        return tieneParabrisas;
    }

    public String toString() {
        return "Moto - Patente: " + getPatente() + ", Parabrisas: " + (tieneParabrisas ? "Sí" : "No");
    }
}
