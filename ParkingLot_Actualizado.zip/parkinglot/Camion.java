package parkinglot;

public class Camion extends Car {
    private int cantidadEjes;

    public Camion(String patente, int cantidadEjes) {
        super(patente);
        this.cantidadEjes = cantidadEjes;
    }

    public int getCantidadEjes() {
        return cantidadEjes;
    }

    public String toString() {
        return "Camión - Patente: " + getPatente() + ", Ejes: " + cantidadEjes;
    }
}
