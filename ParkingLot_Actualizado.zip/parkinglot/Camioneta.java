package parkinglot;

public class Camioneta extends Car {
    private boolean tieneCupula;

    public Camioneta(String patente, boolean tieneCupula) {
        super(patente);
        this.tieneCupula = tieneCupula;
    }

    public boolean tieneCupula() {
        return tieneCupula;
    }

    public String toString() {
        return "Camioneta - Patente: " + getPatente() + ", Cúpula: " + (tieneCupula ? "Sí" : "No");
    }
}
