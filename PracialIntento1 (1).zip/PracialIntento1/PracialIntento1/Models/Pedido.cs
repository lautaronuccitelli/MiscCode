using System.Collections.Generic;

namespace Models;

public class Pedido
{
    public string Cliente { get; set; }
    public string Direccion { get; set; }
    public List<Producto> Productos { get; set; } = new List<Producto>();
    public string TipoEnvio { get; set; } 
    public decimal Subtotal { get; set; }
    public decimal CostoEnvio { get; set; }
    public decimal Total { get; set; }

    public Pedido() { } 
}