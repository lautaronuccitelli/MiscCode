namespace Strategy;

using Models;

public class MotoStrategy : IEnvioStrategy
{
    public decimal CalcularCosto(Pedido pedido)
    {
        return 500.00m; 
    }
}