namespace Strategy;

using Models;

public class CorreoStrategy : IEnvioStrategy
{
    public decimal CalcularCosto(Pedido pedido)
    {
        return pedido.Subtotal * 0.10m + 100m;
    }
}