namespace Strategy;

using Models;

public interface IEnvioStrategy
{
    decimal CalcularCosto(Pedido pedido);
}