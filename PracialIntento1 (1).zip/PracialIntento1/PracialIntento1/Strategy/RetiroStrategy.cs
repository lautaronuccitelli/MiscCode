namespace Strategy;

using Models;

public class RetiroStrategy : IEnvioStrategy
{
    public decimal CalcularCosto(Pedido pedido)
    {
        return 0.00m;
    }
}