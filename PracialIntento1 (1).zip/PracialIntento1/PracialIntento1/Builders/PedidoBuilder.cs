namespace Builders;

using Models;
using Strategy;
using System.Linq;

public class PedidoBuilder: IPedidoBuilder
{
    private Pedido _pedido;

    public PedidoBuilder()
    {
        Reset();
    }

    public void Reset()
    {
        _pedido = new Pedido();
    }

    private void RecalcularTotales()
    {
        _pedido.Subtotal = _pedido.Productos.Sum(p => p.Precio * p.Cantidad);
        _pedido.Total = _pedido.Subtotal + _pedido.CostoEnvio;
    }
    
    public void AgregarProducto(Producto producto)
    {
        _pedido.Productos.Add(producto);
        RecalcularTotales();
    }

    public void ConCliente(string cliente)
    {
        _pedido.Cliente = cliente;
    }

    public void ConDireccion(string direccion)
    {
        _pedido.Direccion = direccion;
    }

    public void AplicarEnvio(IEnvioStrategy envioStrategy)
    {
        _pedido.CostoEnvio = envioStrategy.CalcularCosto(_pedido);
        _pedido.TipoEnvio = envioStrategy.GetType().Name.Replace("Strategy", "");
        RecalcularTotales();
    }

    public Pedido Build()
    {
        if (string.IsNullOrEmpty(_pedido.Cliente) || _pedido.Productos.Count == 0)
        {
            throw new Exception("El cliente no puede ser nulo y/o debe haber al menos 1 producto.");
        }
        Pedido resultado = _pedido;
        Reset();
        return resultado;
    }
}