using Strategy;
using Models;

namespace Builders;


public interface IPedidoBuilder
{
    void Reset();
    void AgregarProducto(Producto producto);
    void ConCliente(String cliente);
    void ConDireccion(String direccion);
    void AplicarEnvio(IEnvioStrategy envioStrategy);
    Pedido Build();
}