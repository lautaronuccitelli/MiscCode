﻿using Controllers;
using Data;
using Models;
using Services;
using Strategy;

class Program
{
    static void Main()
    {
        var repo = new RepositorioJson();
        var service = new PedidoService(); 
        
        service.OnPedidoConfirmado += new ClienteObserver().Actualizar;
        service.OnPedidoConfirmado += new LogisticaObserver().Actualizar;
        
        var controller = new PedidoController(repo, service);

        bool continuar = true;
        do
        {
            Console.Clear();
            Console.WriteLine("1. Agregar Producto al Pedido");
            Console.WriteLine("2. Seleccionar Estrategia de Envío");
            Console.WriteLine("3. Confirmar Pedido");
            Console.WriteLine("4. Listar Pedidos Guardados");
            Console.WriteLine("5. Salir");
            Console.Write("Seleccione una opción: ");
            string opcion = Console.ReadLine();
            switch(opcion)
            {
                case"1":
                    AgregarProducto(controller);
                    break;
                case "2":
                    SeleccionarEnvio(controller);
                    break;
                case "3":
                    ConfirmarPedido(controller);
                    break;
                case "4":
                    Listar(controller);
                    break;
                case "5":
                    continuar = false;
                    Console.WriteLine("Saliendo...");
                    break;
            }

            if (continuar)
            {
                Console.WriteLine("Pesione ENTER para continuar...");
                Console.ReadLine();
            }
        }while(continuar);
    }
    
    private static void msg(string texto, ConsoleColor color = ConsoleColor.White)
    {
        Console.ForegroundColor = color;
        Console.WriteLine(texto);
        Console.ResetColor();
    }

    private static void AgregarProducto(PedidoController controller)
    {
        Console.WriteLine("Nombre del producto: ");
        string nomrbe = Console.ReadLine();
        Console.WriteLine("Precio del producto: ");
        int precio = int.Parse(Console.ReadLine());
        Console.WriteLine("Cantidad del producto: ");
        int cantidad = int.Parse(Console.ReadLine());
        controller.AgregarProducto(nomrbe, cantidad, precio);
    }

    private static void SeleccionarEnvio(PedidoController controller)
    {
        Console.WriteLine("1. Moto.");
        Console.WriteLine("2. Correo.");
        Console.WriteLine("3. Retiro en el local (opcion default).");
        Console.WriteLine("Selecionar una opcion.");
        string opcion = Console.ReadLine();

        IEnvioStrategy envio;
        switch (opcion)
        {
            case "1":
                envio = new MotoStrategy();
                break;
            case "2":
                envio = new CorreoStrategy();
                break;
            case "3":
                envio = new RetiroStrategy();
                break;
            default:
                msg("Opcion no valida. Dejando al envio por defautl (retiro en el local).", ConsoleColor.Red);
                return;
        }
        
        controller.SeleccionarEnvio(envio);
    }

    private static void ConfirmarPedido(PedidoController controller)
    {
        Console.WriteLine("Nombre del cliente: ");
        string cliente = Console.ReadLine();
        Console.WriteLine("Direccion del cliente: ");
        string direccion = Console.ReadLine();
        controller.ConfirmarPedido(cliente, direccion);
    }

    private static void Listar(PedidoController controller)
    {
        List<Pedido> pedidos = controller.ObtenerPedidos();
        if(pedidos.Count == 0)
        {
            msg("No hay pedidos guardados.", ConsoleColor.Red);
            return;
        }

        foreach (var p in pedidos)
        {
            Console.WriteLine($" Cliente: {p.Cliente} | Envío: {p.TipoEnvio}");
            Console.WriteLine($" Cantidad: {p.Productos.Count} | Subtotal: ${p.Subtotal} ");
            Console.WriteLine($" TOTAL: ${p.Total}");
        }
    }
}
