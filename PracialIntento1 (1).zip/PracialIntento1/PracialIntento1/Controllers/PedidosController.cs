namespace Controllers;

using Builders;
using Data;
using Models;
using Services;
using Strategy;

public class PedidoController()
{
    
    private readonly IPedidoBuilder _builder;
    private readonly PedidoService _service;
    private readonly IRepositorio<Pedido> _repositorio;
    private IEnvioStrategy _currentStrategy;

    public PedidoController(IRepositorio<Pedido> repositorio, PedidoService service) : this()
    {
        _repositorio = repositorio;
        _service = service;
        _builder = new PedidoBuilder();
        _currentStrategy = new CorreoStrategy();
        _builder.AplicarEnvio(_currentStrategy);
    }
    
    private void msg(string texto, ConsoleColor color = ConsoleColor.White)
    {
        Console.ForegroundColor = color;
        Console.WriteLine(texto);
        Console.ResetColor();
    }

    public void AgregarProducto(string n, int c, decimal p)
    {
        if (p <= 0 || c <= 0)
        {
            msg("El producto debe tener un precio y cantidad mayor a 0.", ConsoleColor.Red);
        }

        _builder.AgregarProducto(new Producto { Nombre = n, Cantidad = c, Precio = p });
        _builder.AplicarEnvio(_currentStrategy);
        msg("Producto agregado correctamente.", ConsoleColor.Green);;
    }

    public void SeleccionarEnvio(IEnvioStrategy envio)
    {
        _currentStrategy = envio;
        _builder.AplicarEnvio(envio);
        msg("Envio agregado correctamente.", ConsoleColor.Green);
    }
    
    public void ConfirmarPedido(string cliente, string direccion)
    {
        if (string.IsNullOrWhiteSpace(cliente) || string.IsNullOrWhiteSpace(direccion))
        {
            msg("El cliente debe tener cliente y direccion.", ConsoleColor.Red);
        }
        _builder.ConCliente(cliente);
        _builder.ConDireccion(direccion);
        Pedido pedido = _builder.Build();
        _repositorio.Guardar(pedido);
        _service.Confirmar(pedido);
    }
    
    public List<Pedido> ObtenerPedidos()
    {
        return _repositorio.ObtenerTodos();
    }
}
