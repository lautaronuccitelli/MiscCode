namespace Services;

using Models;

public class LogisticaObserver
{
    public void Actualizar(Pedido pedido)
    {
        Console.WriteLine($"[OBSERVER: LOGÍSTICA] Pedido para {pedido.Direccion} listo para {pedido.TipoEnvio}. Costo de envío: ${pedido.CostoEnvio}.");
    }
}
