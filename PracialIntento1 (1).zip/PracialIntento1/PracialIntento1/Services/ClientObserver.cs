namespace Services;

using Models;

public class ClienteObserver
{
    public void Actualizar(Pedido pedido)
    {
        Console.WriteLine($"[OBSERVER: CLIENTE] Estimado {pedido.Cliente}, su pedido N° {pedido.GetHashCode()} por ${pedido.Total} ha sido CONFIRMADO. ¡Gracias!");
    }
}
