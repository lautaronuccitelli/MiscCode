namespace Services;

using Models;

public class PedidoService
{
    public delegate void PedidoConfirmadoEventHandler(Pedido pedido);
    public event PedidoConfirmadoEventHandler OnPedidoConfirmado;

    public void Confirmar(Pedido pedido)
    {
        Console.WriteLine("\n[SERVICE] Pedido confirmado. Disparando notificaciones...");
        OnPedidoConfirmado?.Invoke(pedido);
    }
}
