﻿using System;
using Controller;
using Models;
using Strategy;
using Data;

namespace MiProyectoParcial
{
    class Program
    {
        static void Main(string[] args)
        {
            var facade = new ReservaController();
            bool salir = false;
            
            while (!salir)
            {
                Console.Clear();
                Console.WriteLine("=== SISTEMA DE RESERVAS DE VIAJES ===");
                Console.WriteLine("Nombre: TU_NOMBRE_AQUI\n"); // CAMBIA ESTO
                
                Console.WriteLine("1) Agregar destino");
                Console.WriteLine("2) Seleccionar transporte");
                Console.WriteLine("3) Confirmar reserva");
                Console.WriteLine("4) Listar reservas");
                Console.WriteLine("5) Salir");
                Console.Write("\nOpción: ");
                
                string opcion = Console.ReadLine();
                
                switch (opcion)
                {
                    case "1":
                    case "2":
                    case "3":
                        facade.CrearReserva();
                        break;
                    case "4":
                        facade.ListarReservas();a
                        break;
                    case "5":
                        salir = true;
                        Console.WriteLine("\n¡Hasta luego!");
                        break;
                    default:
                        Console.WriteLine("\nOpción inválida");
                        Console.ReadLine();
                        break;
                }
            }        }
    }
}
