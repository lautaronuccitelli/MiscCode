using System;
using System.Collections.Generic;
using Data;
using Models;
using Service;
using Strategy;
using Builder;
using System.Runtime.ConstrainedExecution;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Channels;
using System.Net.Http.Headers;
using System.Linq;

namespace Controller
{
    public class ReservaController
    {
        private readonly IRepositorio<Reserva> _reserva;
        private readonly ReservaService _service;
        private readonly ReservaBuilder _builder;

        public readonly Dictionary<int, ITransporteStrategy> _estrategias;

        public ReservaController()
        {
            _reserva = new RepositorioJson<Reserva>(); 
            _service = new ReservaService();            
            _builder = new ReservaBuilder(); 

            _estrategias = new Dictionary<int, ITransporteStrategy>{
                {1 , new TransporteAvion()},
                {2, new TransporteMicro()},
                {3, new TransporteAuto()},
            };

            var ClienteObs = new ClienteObserver();
            var AgenciaObs = new AgenciaObserver();

            _service.ReservaConfirmada += ClienteObs.OnReservaConfirmada;
            _service.ReservaConfirmada += AgenciaObs.OnReservaConfirmada;
        }

        public void CrearReserva(){
            try{
                Console.Clear();
                System.Console.WriteLine("NUEVA RESERVA.");
                System.Console.Write("Nombre del viajero: ");
                string viajero = Console.ReadLine();

                if(string.IsNullOrWhiteSpace(viajero)){
                    Mensajes.Msg("El nombre del viajero no puede ser nulo.", ConsoleColor.Red);
                    return;
                }

                _builder.ConViajero(viajero);

                Console.Write("Fecha de inicio (yyyy-MM-dd): ");
                if(!DateTime.TryParse(Console.ReadLine(), out DateTime fecha)){
                    Mensajes.Msg("ERROR: fecha invalida.", ConsoleColor.Red);
                    return;
                }

                _builder.ConFechaInicio(fecha);

                bool agregarMas = true;
                while(agregarMas){
                    System.Console.WriteLine("AGREGAR DESTINO(s).");
                    System.Console.Write("Nombre del destino: ");
                    string nombreDes = Console.ReadLine();

                    Console.Write("Precio Base: ");
                    if(!decimal.TryParse(Console.ReadLine(), out decimal precio)){
                        System.Console.WriteLine("PRECIO INVALIDO: usando 100000");
                        precio = 100000;
                    }

                    Console.Write("Duracion dias: ");
                    if(!int.TryParse(Console.ReadLine(), out int dias)){
                        System.Console.WriteLine("Duracion invalida, usando 5 dias");
                        dias = 5;
                    }

                    var destino = new Destino(nombreDes, precio, dias);
                    _builder.AgregarDestino(destino);

                    Console.Write("Desea agregar otro destino?(S/n): ");
                    agregarMas = Console.ReadLine()?.ToLower() == "s";
                }

                System.Console.WriteLine("SELECIONAR TRANSPORTE.");
                System.Console.WriteLine("1) Avion (10% de descuento).");
                System.Console.WriteLine("2) Micro (5% de descuento).");
                System.Console.WriteLine("3) Auto (Precio fijo: 40k).");
                System.Console.Write("Seleciona una opcion: ");

                if(int.TryParse(Console.ReadLine(), out int opcion) && _estrategias.ContainsKey(opcion)){
                    _builder.ConTransporte(_estrategias[opcion]);
                }
                else{
                    System.Console.WriteLine("Opcion invalida, usando auto por defecto.");
                    _builder.ConTransporte(_estrategias[3]);
                }

                var reserva = _builder.Build();

                System.Console.WriteLine("Resumen de la reserva.");
                Console.WriteLine($"Viajero: {reserva.Viajeros}");
                Console.WriteLine($"Fecha: {reserva.FechaInicio:yyyy-MM-dd}");
                Console.WriteLine($"Destinos: {reserva.Destinos.Count}");
                Console.WriteLine($"Transporte: {reserva.MedioTransporte}");
                Console.WriteLine($"TOTAL: ${reserva.Total:N2}");
                
                Console.Write("¿Confirmar reserva? (s/n): ");
                if(Console.ReadLine()?.ToLower() == "s"){
                    _service.Confirmar(reserva);
                    _reserva.Guardar(reserva);
                    Mensajes.Msg("Reserva confirmada y guardada.", ConsoleColor.Green);
                } 
                else{
                    Mensajes.Msg("Reserva cancelada", ConsoleColor.Red);
                }
            }
            catch(Exception ex){
                System.Console.WriteLine("Error:  {ex.Message}");
            }
            System.Console.WriteLine("Presione cualquier tecla para continuar.");
            Console.ReadLine();
        }

        public void ListarReservas(){
            Console.Clear();
            System.Console.WriteLine("RESERVAS GUARDADAS.");

            var reservas = _reserva.Listar();

            if(!reservas.Any()){
                Mensajes.Msg("No hay reservas guardadas", ConsoleColor.Red);
            }

            else{
                int i = 1;
                foreach(var r in reservas){
                    Console.WriteLine($"--- Reserva #{i++} ---");
                    Console.WriteLine($"Viajero: {r.Viajeros}");
                    Console.WriteLine($"Fecha: {r.FechaInicio:yyyy-MM-dd}");
                    Console.WriteLine($"Destinos: {r.Destinos?.Count ?? 0}");
                    Console.WriteLine($"Transporte: {r.MedioTransporte}");
                    Console.WriteLine($"Total: ${r.Total:N2}");
                    Console.WriteLine();
                }
            }

            Console.WriteLine("Presione Enter para continuar...");
            Console.ReadLine();
        }
    }
}