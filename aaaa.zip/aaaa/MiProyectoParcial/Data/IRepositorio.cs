using System;
using System.Collections.Generic;

namespace Data
{
    public interface IRepositorio<T>
    {
        void Guardar(T entidad);
        IEnumerable<T> Listar();
    }
}