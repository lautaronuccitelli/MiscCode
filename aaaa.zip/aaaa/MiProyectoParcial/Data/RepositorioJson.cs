using System;
using System.Collections.Generic;

namespace Data
{
    public class RepositorioJson<T> : IRepositorio<T>
    {
        private readonly string _archivo = "reservas.json";
        private List<T> _datos;

        public RepositorioJson()
        {
            _datos = new List<T>();
            CargarDesdeArchivo();
        }

        public void Guardar(T entidad)
        {
            try
            {
                _datos.Add(entidad);
                GuardarEnArchivo();
                Console.WriteLine("Reserva guardada exitosamente");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al guardar: {ex.Message}");
            }
        }

        public IEnumerable<T> Listar()
        {
            return _datos;
        }

        private void GuardarEnArchivo()
        {
            try
            {
                string json = System.Text.Json.JsonSerializer.Serialize(_datos, 
                    new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
                System.IO.File.WriteAllText(_archivo, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al escribir archivo: {ex.Message}");
            }
        }

        private void CargarDesdeArchivo()
        {
            try
            {
                if (System.IO.File.Exists(_archivo))
                {
                    string json = System.IO.File.ReadAllText(_archivo);
                    _datos = System.Text.Json.JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al leer archivo: {ex.Message}");
                _datos = new List<T>();
            }
        }
    }
}
