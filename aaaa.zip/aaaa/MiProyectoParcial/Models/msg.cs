using System;

namespace Models
{
    public class Mensajes
    {
        public static void Msg(string texto, ConsoleColor color = ConsoleColor.White)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(texto);
            Console.ResetColor();
        }
    }
}
