using System;
using System.Collections.Generic;

namespace Models
{
    public class Reserva
    {
        public string Viajeros { get; set; }
        public DateTime FechaInicio { get; set; }
        public List<Destino> Destinos { get; set; }
        public string MedioTransporte { get; set; }
        public decimal Total { get; set; }
        
        public Reserva()
        {
            Destinos = new List<Destino>();
        }
    }
}