using System;

namespace Models
{
    public class Destino
    {
        public string Nombre { get; set; }
        public decimal PrecioBase { get; set; }
        public int Duracion { get; set; }

        public Destino(string nombre, decimal precioBase, int duracion)
        {
            Nombre = nombre;
            PrecioBase = precioBase;
            Duracion = duracion;
        }
    }
}