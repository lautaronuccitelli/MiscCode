using System;
using System.Collections.Generic;
using Models;

namespace Strategy
{
    public class TransporteAuto : ITransporteStrategy
    {
        public string Nombre => "Auto";

        public decimal CalcularCosto(IEnumerable<Destino> destinosm, decimal subtotal)
        {
            decimal CostoFijo = 40.000m;
            return subtotal + CostoFijo;
        }
    }
}