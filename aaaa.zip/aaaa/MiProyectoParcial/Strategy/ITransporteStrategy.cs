using System;
using System.Collections.Generic;
using Models;

namespace Strategy
{
    public interface ITransporteStrategy
    {
        string Nombre { get; }
        decimal CalcularCosto(IEnumerable<Destino> destinos, decimal subtotal);
    }
}