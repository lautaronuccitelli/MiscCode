using System;
using System.Collections.Generic;
using Models;

namespace Strategy
{
    public class TransporteAvion : ITransporteStrategy
    {
        public string Nombre => "Avion";
        
        public decimal CalcularCosto(IEnumerable<Destino> destinos, decimal subtotal)
        {
            return subtotal * 0.10m;
        }
    }
}