using System;
using System.Collections.Generic;
using Models;

namespace Strategy
{
    public class TransporteMicro : ITransporteStrategy
    {
        public string Nombre => "Micro";

        public decimal CalcularCosto(IEnumerable<Destino> destinos, decimal subtotal)
        {
            return subtotal * 0.95m;
        }
    }
}