using System;
using Models;

namespace Service
{
    public class ReservaConfirmadaEventArgs: EventArgs
    {
        public Reserva Reserva { get; }

        public ReservaConfirmadaEventArgs(Reserva reserva)
        {
            Reserva = reserva;
        }
    }
}