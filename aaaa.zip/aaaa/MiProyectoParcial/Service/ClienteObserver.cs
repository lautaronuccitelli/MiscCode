using System;

namespace Service
{
    public class ClienteObserver
    {
        public void OnReservaConfirmada(object sender, ReservaConfirmadaEventArgs e){
            Console.WriteLine($"-CLIENTE- Reserva confirmada para: {e.Reserva.Viajeros} | Total: {e.Reserva.Total}");
        }
        
    }
}