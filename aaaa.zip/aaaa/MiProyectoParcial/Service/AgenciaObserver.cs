using System;
using Models;

namespace Service
{
    public class AgenciaObserver {
        public void OnReservaConfirmada(object sender, ReservaConfirmadaEventArgs e){
            Console.WriteLine($"-Agencia- Reseva confimada para: {e.Reserva.Viajeros} | Desinto: {e.Reserva.Destinos}");
        }
    }
}