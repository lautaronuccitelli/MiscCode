using System;
using Models;

namespace Service
{
    public class ReservaService
    {
        public event EventHandler<ReservaConfirmadaEventArgs> ReservaConfirmada;

        public void Confirmar(Reserva reserva)
        {
            // Validar, persistir y disparar evento
            if (reserva == null)
                throw new ArgumentNullException(nameof(reserva));

            ReservaConfirmada?.Invoke(this, new ReservaConfirmadaEventArgs(reserva));
        }
    }
}