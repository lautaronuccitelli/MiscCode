using System;
using System.Collections.Generic;
using Models;
using Strategy;

namespace Builder
{
    public interface IReservaBuilder
    {
        IReservaBuilder ConViajero(string nombre);
        IReservaBuilder ConFechaInicio(DateTime fecha);
        IReservaBuilder AgregarDestino(Destino destino);
        IReservaBuilder ConTransporte(ITransporteStrategy estrategia);
        Reserva Build();
    }
}