using System;
using Models;
using Strategy;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace Builder
{
    public class ReservaBuilder : IReservaBuilder
    {
        private Reserva _reserva;
        private ITransporteStrategy _estrategia;

        public ReservaBuilder()
        {
            _reserva = new Reserva();
        }
        
        public IReservaBuilder ConViajero(string nombre)
        {
            _reserva.Viajeros = nombre;
            return this;
        }

        public IReservaBuilder ConFechaInicio(DateTime fecha)
        {
            _reserva.FechaInicio = fecha;
            return this;
        }

        public IReservaBuilder AgregarDestino(Destino destino)
        {
            _reserva.Destinos.Add(destino);
            return this;
        }

        public IReservaBuilder ConTransporte(ITransporteStrategy estrategia)
        {
            _estrategia = estrategia;
            _reserva.MedioTransporte = _estrategia.Nombre;
            return this;
        }

        public Reserva Build()
        {
            if (String.IsNullOrWhiteSpace(_reserva.Viajeros)){
                Mensajes.Msg("El nombre del viajero no puede ser nulo.", ConsoleColor.Red);
            }
            if(_reserva.Destinos.Count == 0){
                Mensajes.Msg("Los destinos no puede ser nulos.", ConsoleColor.Red);
            }
            if(_reserva.FechaInicio == default){
                Mensajes.Msg("La fecha de inicio no puede estar vacia.", ConsoleColor.Red);
            }
            if(_reserva.FechaInicio < DateTime.Now){
                Mensajes.Msg("La fecha no peude ser un dia pasado.", ConsoleColor.Red);
            }

            decimal subtotal = 0;
            foreach (var d in _reserva.Destinos){
                subtotal += d.PrecioBase;
            }

            if(_reserva.Destinos.Count > 2){
                subtotal *= 0.90m;
            }

            if(_estrategia != null){
                _reserva.Total = _estrategia.CalcularCosto(_reserva.Destinos, subtotal);
            }
            else{
                _reserva.Total = subtotal;
            }

            return _reserva;
        }
    }
}