﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.Decorator.Interfaces;
using PatronesDeDiseno.Decorator.Base;
using PatronesDeDiseno.Decorator.Decorators;

namespace PatronesDeDiseno.Decorator.Services
{
    public class SistemaMensajeria
    {
        public void DemostrarPatron()
        {
            Console.WriteLine("=== DEMOSTRACION DEL PATRON DECORATOR ===");
            Console.WriteLine();

            string textoOriginal = "Hola mundo";

            Console.WriteLine("1. Mensaje simple (sin decoradores):");
            IMensaje mensajeSimple = new MensajeSimple();
            mensajeSimple.Enviar(textoOriginal);

            Console.WriteLine();
            Console.WriteLine("2. Mensaje con encriptacion:");
            IMensaje mensajeEncriptado = new MensajeEncriptado(new MensajeSimple());
            mensajeEncriptado.Enviar(textoOriginal);

            Console.WriteLine();
            Console.WriteLine("3. Mensaje con emoji:");
            IMensaje mensajeConEmoji = new MensajeConEmoji(new MensajeSimple());
            mensajeConEmoji.Enviar(textoOriginal);

            Console.WriteLine();
            Console.WriteLine("4. Mensaje con ambos decoradores (encriptacion + emoji):");
            IMensaje mensajeCompleto = new MensajeConEmoji(
                new MensajeEncriptado(
                    new MensajeSimple()
                )
            );
            mensajeCompleto.Enviar(textoOriginal);

            Console.WriteLine();
            Console.WriteLine("5. Mensaje con decoradores en orden diferente (emoji + encriptacion):");
            IMensaje mensajeInverso = new MensajeEncriptado(
                new MensajeConEmoji(
                    new MensajeSimple()
                )
            );
            mensajeInverso.Enviar(textoOriginal);

            Console.WriteLine();
            Console.WriteLine("=== PATRON DECORATOR COMPLETADO ===");
        }
    }
}
