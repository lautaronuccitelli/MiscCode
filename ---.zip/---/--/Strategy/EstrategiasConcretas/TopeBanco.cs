using System;
using PatronesDeDiseno.Strategy;

namespace PatronesDeDiseno.Strategy.EstrategiasConcretas
{
    public class TopeBanco: IDescuentoStrategy
    {
        public string Nombre => "Tope Banco";
        public decimal Aplicar(decimal subtotal) 
        {
            // Corregido: aplica descuento con tope máximo de $100
            decimal descuento = subtotal * 0.15m; // 15% descuento
            decimal topeDescuento = 100m;
            return subtotal - Math.Min(descuento, topeDescuento);
        }
    }
}