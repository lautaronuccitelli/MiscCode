﻿using System;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.GoogleMaps
{
    public class GoogleGeocoder : IGeocoder
    {
        public void Buscar(string direccion)
        {
            Console.WriteLine($"[Google Geocoding] Buscando dirección: {direccion}");
            Console.WriteLine("- Conectando a Google Geocoding API...");
            Console.WriteLine("- Procesando con algoritmos de Google...");
            Console.WriteLine($"- Resultado: Lat: -38.0055, Lng: -57.5426 (Google)");
        }
    }
}