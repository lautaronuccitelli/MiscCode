﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.Facade.Interfaces;
using PatronesDeDiseno.Facade.Subsystems;

namespace PatronesDeDiseno.Facade.Facades
{
    public class UserFacade : IUserFacade
    {
        private readonly DBService _dbService;
        private readonly EmailValidator _emailValidator;
        private readonly EmailSender _emailSender;

        public UserFacade()
        {
            _dbService = new DBService();
            _emailValidator = new EmailValidator();
            _emailSender = new EmailSender();
        }

        public bool RegistrarUsuario(string nombre, string email)
        {
            Console.WriteLine($"[USER FACADE] Iniciando registro de usuario: {nombre}");
            Console.WriteLine();

            if (!_emailValidator.EsValido(email))
            {
                Console.WriteLine($"[USER FACADE] Registro fallido: email invalido");
                return false;
            }

            Console.WriteLine();
            if (!_dbService.GuardarUsuario(nombre, email))
            {
                Console.WriteLine($"[USER FACADE] Registro fallido: error en base de datos");
                return false;
            }

            Console.WriteLine();
            if (!_emailSender.EnviarBienvenida(email))
            {
                Console.WriteLine($"[USER FACADE] Advertencia: usuario creado pero fallo el envio de email");
            }

            Console.WriteLine();
            Console.WriteLine($"[USER FACADE] Usuario registrado exitosamente!");
            return true;
        }
    }
}
