﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronesDeDiseno.Facade.Subsystems
{
    public class EmailSender
    {
        public bool EnviarBienvenida(string email)
        {
            Console.WriteLine($"[EMAIL SENDER] Preparando correo de bienvenida...");
            Console.WriteLine($"[EMAIL SENDER] Enviando correo a: {email}");
            Console.WriteLine($"[EMAIL SENDER] Correo de bienvenida enviado exitosamente");
            return true;
        }
    }
}
