using System;
using System.Collections.Generic;
using System.Linq;

namespace PatronesDeDiseno.Command.Receiver
{
    public class Carrito
    {
        private readonly Dictionary<string, Item> _items = new();
    
        public void Agregar(Item item)
        {
            if (_items.ContainsKey(item.Sku))
            {
                _items[item.Sku].Cantidad += item.Cantidad;
            }
            else
            {
                _items[item.Sku] = new Item(item.Sku, item.Nombre, item.Precio, item.Cantidad);
            }
        }
    
        public void Quitar(string sku)
        {
            _items.Remove(sku);
        }
    
        public void CambiarCantidad(string sku, int nuevaCantidad)
        {
            if (_items.ContainsKey(sku))
            {
                _items[sku].Cantidad = nuevaCantidad;
            }
        }
    
        public decimal Total()
        {
            return _items.Values.Sum(item => item.Precio * item.Cantidad);
        }
    
        public Item GetItem(string sku)
        {
            return _items.ContainsKey(sku) ? _items[sku] : null;
        }
    
        public void MostrarItems()
        {
            foreach (var item in _items.Values)
            {
                Console.WriteLine($"{item.Sku}: {item.Nombre} - ${item.Precio} x {item.Cantidad}");
            }
        }
    }
}