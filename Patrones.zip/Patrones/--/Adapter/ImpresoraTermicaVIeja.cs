﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronesDeDiseno.Adapter.Legacy
{
    public class ImpresoraTermicaVieja
    {
        private const int limiteCaracteres = 100;
        public void PrintTicket(string data)
        {
            if (data.Length > limiteCaracteres)
            {
                data = data.Substring(0, limiteCaracteres) + "...";
            }
            Console.WriteLine($"[IMPRESORA TERMICA VIEJA] Imprimiendo: {data}");
        }
    }
}
