﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.Adapter.Interfaces;
using PatronesDeDiseno.Adapter.Legacy;

namespace PatronesDeDiseno.Adapter.Adapters
{
    public class AdaptadorTermica : IImpresora
    {
        private readonly ImpresoraTermicaVieja _impresoraVieja;

        public AdaptadorTermica(ImpresoraTermicaVieja impresoraVieja)
        {
            _impresoraVieja = impresoraVieja;
        }

        public void Imprimir(string texto)
        {
            Console.WriteLine("[ADAPTADOR] Convirtiendo llamada moderna a formato viejo...");
            _impresoraVieja.PrintTicket(texto);
        }
    }
}
