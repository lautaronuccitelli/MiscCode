﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.Adapter.Interfaces;

namespace PatronesDeDiseno.Adapter.Modern
{
    public class ImpresoraLaser : IImpresora
    {
        public void Imprimir(string texto)
        {
            Console.WriteLine($"[IMPRESORA LASER MODERNA] Imprimiendo en alta calidad: {texto}");
        }
    }
}
