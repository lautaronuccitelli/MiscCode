﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronesDeDiseno.Adapter.Interfaces
{
    public interface IImpresora
    {
        void Imprimir(string texto);
    }
}
