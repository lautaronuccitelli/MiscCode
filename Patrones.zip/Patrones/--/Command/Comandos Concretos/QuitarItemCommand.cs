using PatronesDeDiseno.Command.Receiver;


namespace PatronesDeDiseno.Command.Comandos_Concretos
{
    public class QuitarItemCommand : ICommand
    {
        private readonly Carrito _carrito;
        private readonly string _sku;
        private Item _backup; 
    
        public QuitarItemCommand(Carrito carrito, string sku)
        {
            _carrito = carrito;
            _sku = sku;
        }
    
        public void Execute()
        {
            _backup = _carrito.GetItem(_sku);
            if (_backup != null)
            {
                _backup = new Item(_backup.Sku, _backup.Nombre, _backup.Precio, _backup.Cantidad);
            }
            _carrito.Quitar(_sku);
        }
    
        public void Undo()
        {
            if (_backup != null)
            {
                _carrito.Agregar(_backup);
            }
        }
    }
}