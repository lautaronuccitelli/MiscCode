using PatronesDeDiseno.Command.Receiver;

namespace PatronesDeDiseno.Command.Comandos_Concretos
{
    public class CambiarCantidadCommand : ICommand
    {
        private readonly Carrito _carrito;
        private readonly string _sku;
        private readonly int _nuevaCantidad;
        private int _cantidadAnterior;
    
        public CambiarCantidadCommand(Carrito carrito, string sku, int nuevaCantidad)
        {
            _carrito = carrito;
            _sku = sku;
            _nuevaCantidad = nuevaCantidad;
        }
    
        public void Execute()
        {
            var item = _carrito.GetItem(_sku);
            if (item != null)
            {
                _cantidadAnterior = item.Cantidad; 
                _carrito.CambiarCantidad(_sku, _nuevaCantidad);
            }
        }
    
        public void Undo()
        {
            _carrito.CambiarCantidad(_sku, _cantidadAnterior);
        }
    }

}