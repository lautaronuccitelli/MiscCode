using System;
using System.Collections.Generic;

namespace PatronesDeDiseno.Command.Receiver
{
    public class Carrito
    {
        private readonly List<Item> _items = new();

        public void Agregar(Item item)
        {
            Item existente = null;

            foreach (var i in _items)
            {
                if (i.Sku == item.Sku)
                {
                    existente = i;
                    break;
                }
            }

            if (existente != null)
            {
                existente.Cantidad += item.Cantidad;
            }
            else
            {
                _items.Add(new Item(item.Sku, item.Nombre, item.Precio, item.Cantidad));
            }
        }

        public void Quitar(string sku)
        {
            Item encontrado = null;

            foreach (var i in _items)
            {
                if (i.Sku == sku)
                {
                    encontrado = i;
                    break;
                }
            }

            if (encontrado != null)
            {
                _items.Remove(encontrado);
            }
        }

        public void CambiarCantidad(string sku, int nuevaCantidad)
        {
            foreach (var i in _items)
            {
                if (i.Sku == sku)
                {
                    i.Cantidad = nuevaCantidad;
                    break;
                }
            }
        }

        public decimal Total()
        {
            decimal total = 0;

            foreach (var i in _items)
            {
                total += i.Precio * i.Cantidad;
            }

            return total;
        }

        public Item GetItem(string sku)
        {
            foreach (var i in _items)
            {
                if (i.Sku == sku)
                {
                    return i;
                }
            }

            return null;
        }

        public void MostrarItems()
        {
            foreach (var item in _items)
            {
                Console.WriteLine($"{item.Sku}: {item.Nombre} - ${item.Precio} x {item.Cantidad}");
            }
        }
    }
}
