﻿using System;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.GoogleMaps
{
    public class GoogleMapa : IMapa
    {
        public void Render(string ubicacion)
        {
            Console.WriteLine($"[Google] Renderizando mapa de: {ubicacion}");
        }
    }
}