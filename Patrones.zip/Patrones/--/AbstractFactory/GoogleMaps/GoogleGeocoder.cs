﻿using System;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.GoogleMaps
{
    public class GoogleGeocoder : IGeocoder
    {
        public void Buscar(string direccion)
        {
            Console.WriteLine($"[Google] Buscando dirección: {direccion}");
            Console.WriteLine($"- Resultado: Lat: -38.0055, Lng: -57.5426 (Google)");
        }
    }
}