﻿using PatronesDeDiseno.AbstractFactory.Interfaces;
using System;

namespace PatronesDeDiseno.AbstractFactory.GoogleMaps
{
    public class GoogleMapServicesFactory : IMapServiceFactory
    {
        public IMapa CreateMap()
        {
            return new GoogleMapa();
        }

        public IGeocoder CreateGeocoder()
        {
            return new GoogleGeocoder();
        }
    }
}