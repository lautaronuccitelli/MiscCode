﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.OpenStreetMap
{
    public class OpenStreetMapServicesFactory : IMapServiceFactory
    {
        public IMapa CreateMap()
        {
            return new OpenStreetMapa();
        }

        public IGeocoder CreateGeocoder()
        {
            return new OpenStreetGeocoder();
        }
    }
}
