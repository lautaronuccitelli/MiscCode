﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.OpenStreetMap
{
    public class OpenStreetGeocoder : IGeocoder
    {
        public void Buscar(string direccion)
        {
            Console.WriteLine($"[OSM] Buscando dirección: {direccion}");
            Console.WriteLine($"- Resultado: Lat: -38.0056, Lng: -57.5427 (OSM)");
        }
    }
}
