﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.OpenStreetMap
{
    public class OpenStreetMapa : IMapa
    {
        public void Render(string ubicacion)
        {
            Console.WriteLine($"[OpenStreetMap] Renderizando mapa de: {ubicacion}");
        }
    }
}
