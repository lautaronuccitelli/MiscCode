using PatronesDeDiseno.Strategy;

namespace PatronesDeDiseno.Strategy.Contexto
{
    public class Carrito
    {
        public IDescuentoStrategy _descuento;
        
        public Carrito(IDescuentoStrategy descuento)
        {
            _descuento = descuento;
        }

        public decimal Total(decimal subtotal) => _descuento.Aplicar(subtotal);
        
        public void SetDescuento(IDescuentoStrategy descuento) => _descuento = descuento;
    }
}