using System;
using PatronesDeDiseno.Strategy;

namespace PatronesDeDiseno.Strategy.EstrategiasConcretas
{
    public class TopeBanco: IDescuentoStrategy
    {
        public string Nombre => "Tope Banco";
        public decimal Aplicar(decimal subtotal) 
        {
            decimal descuento = subtotal * 0.15m; 
            decimal topeDescuento = 100m;
            return subtotal - Math.Min(descuento, topeDescuento);
        }
    }
}