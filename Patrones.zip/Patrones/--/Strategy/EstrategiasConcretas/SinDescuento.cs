using PatronesDeDiseno.Strategy;
namespace PatronesDeDiseno.Strategy.EstrategiasConcretas
{
    public class SinDescuento: IDescuentoStrategy
    {
        public string Nombre => "Promo";
        public decimal Aplicar(decimal subtotal) => subtotal;
    }
    
}