using PatronesDeDiseno.Strategy;

namespace PatronesDeDiseno.Strategy
{
    public class Porcentaje: IDescuentoStrategy
    {
        public string Nombre => "Porcentaje";
        public decimal Aplicar(decimal subtotal) => subtotal * 0.90m;
    }
}