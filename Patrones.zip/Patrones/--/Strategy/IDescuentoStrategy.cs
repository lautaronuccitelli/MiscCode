namespace PatronesDeDiseno.Strategy
{
    public interface IDescuentoStrategy
    {
        decimal Aplicar(decimal subtotal);
        string Nombre { get; }
    }
}