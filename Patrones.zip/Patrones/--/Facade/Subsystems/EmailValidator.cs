﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronesDeDiseno.Facade.Subsystems
{
    public class EmailValidator
    {
        public bool EsValido(string email)
        {
            Console.WriteLine($"[Validador] Verificando email: {email}");
            
            bool valido = !string.IsNullOrEmpty(email) && email.Contains("@");
            
            Console.WriteLine($"[Validador] Email {(valido ? "valido" : "invalido")}");
            return valido;
        }
    }
}
