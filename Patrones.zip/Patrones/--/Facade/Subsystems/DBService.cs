﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronesDeDiseno.Facade.Subsystems
{
    public class DBService
    {
        public bool GuardarUsuario(string nombre, string email)
        {
            Console.WriteLine($"[BD] Guardando usuario: {nombre} - {email}");
            return true;
        }
    }
}
