﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronesDeDiseno.Facade.Subsystems
{
    public class EmailSender
    {
        public void EnviarBienvenida(string email)
        {
            Console.WriteLine($"[Email] Enviando correo de bienvenida a: {email}");
        }
    }
}
