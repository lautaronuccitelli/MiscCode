﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronesDeDiseno.Facade.Interfaces
{
    public interface IUserFacade
    {
        bool RegistrarUsuario(string nombre, string email);
    }
}
