﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.Facade.Interfaces;
using PatronesDeDiseno.Facade.Subsystems;

namespace PatronesDeDiseno.Facade.Facades
{
    public class UserFacade : IUserFacade
    {
        private readonly DBService _dbService = new DBService();
        private readonly EmailValidator _emailValidator = new EmailValidator();
        private readonly EmailSender _emailSender = new EmailSender();

        public bool RegistrarUsuario(string nombre, string email)
        {
            if (!_emailValidator.EsValido(email))
            {
                Console.WriteLine("Registro fallido: email invalido");
                return false;
            }

            if (!_dbService.GuardarUsuario(nombre, email))
            {
                Console.WriteLine("Registro fallido: error en base de datos");
                return false;
            }

            _emailSender.EnviarBienvenida(email);

            Console.WriteLine("Proceso de registro completado");
            return true;
        }
    }
}
