namespace PatronesDeDiseno.Observer
{
    public enum EstadoPedido 
    { 
        Recibido, 
        Preparando, 
        Enviado, 
        Entregado 
    }
}