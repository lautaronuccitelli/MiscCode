using System;

namespace PatronesDeDiseno.Observer.Observadores
{
    public class NotificadorCliente
    {
        public void Suscribir(PedidoService s) => s.EstadoCambiado += OnEstadoCambiado;
        public void Desuscribir(PedidoService s) => s.EstadoCambiado -= OnEstadoCambiado;

        private void OnEstadoCambiado(object? sender, PedidoChangedEventArgs e)
        {
            Console.WriteLine($"[CLIENTE] Tu pedido {e.PedidoId} ahora esta: {e.NuevoEstado}");
        }
    }
}