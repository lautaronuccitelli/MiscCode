using System;

namespace PatronesDeDiseno.Observer.Observadores
{
    public class PanelLogistica
    {
        public void Suscribir(PedidoService s) => s.EstadoCambiado += OnEstadoCambiado;
        public void Desuscribir(PedidoService s) => s.EstadoCambiado -= OnEstadoCambiado;

        private void OnEstadoCambiado(object? sender, PedidoChangedEventArgs e)
        {
            Console.WriteLine($"[LOGISTICA] Pedido {e.PedidoId} => {e.NuevoEstado} ({e.Cuando:HH:mm:ss})");
        }
    }
}