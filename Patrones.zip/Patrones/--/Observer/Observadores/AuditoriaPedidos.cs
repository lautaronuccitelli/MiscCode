using System;

namespace PatronesDeDiseno.Observer.Observadores
{
    public class AuditoriaPedidos
    {
        public void Suscribir(PedidoService s) => s.EstadoCambiado += OnEstadoCambiado;
        public void Desuscribir(PedidoService s) => s.EstadoCambiado -= OnEstadoCambiado;

        private void OnEstadoCambiado(object? sender, PedidoChangedEventArgs e)
        {
            Console.WriteLine($"[AUDITORIA] {e.Cuando:HH:mm:ss} -> Pedido {e.PedidoId} = {e.NuevoEstado}");
        }
    }

}