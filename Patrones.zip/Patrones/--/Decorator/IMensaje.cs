﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronesDeDiseno.Decorator.Interfaces
{
    public interface IMensaje
    {
        void Enviar(string texto);
    }
}
