﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.Decorator.Interfaces;
using PatronesDeDiseno.Decorator.Base;
using PatronesDeDiseno.Decorator.Decorators;

namespace PatronesDeDiseno.Decorator.Services
{
    public class SistemaMensajeria
    {
        public void DemostrarPatron()
        {
            Console.WriteLine("=== DEMOSTRACION DEL PATRON DECORATOR ===");
            Console.WriteLine();

            IMensaje mensaje = new MensajeSimple();
            mensaje.Enviar("Hola mundo");

            mensaje = new MensajeEncriptado(new MensajeSimple());
            mensaje.Enviar("Hola mundo");

            mensaje = new MensajeConEmoji(new MensajeSimple());
            mensaje.Enviar("Hola mundo");
            
            mensaje = new MensajeEncriptado(new MensajeConEmoji(new MensajeSimple()));
            mensaje.Enviar("Hola mundo");

            Console.WriteLine();
            Console.WriteLine("=== PATRON DECORATOR COMPLETADO ===");
        }
    }
}
