﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.Decorator.Interfaces;
using PatronesDeDiseno.Decorator.Abstract;

namespace PatronesDeDiseno.Decorator.Decorators
{
    public class MensajeEncriptado : MensajeDecorator
    {
        public MensajeEncriptado(IMensaje mensaje) : base(mensaje)
        {
        }

        public override void Enviar(string texto)
        {
            string textoEncriptado = texto.ToUpper();
            _mensaje.Enviar(textoEncriptado);
        }
    }
}
