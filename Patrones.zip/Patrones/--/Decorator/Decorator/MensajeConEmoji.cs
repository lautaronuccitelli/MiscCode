﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatronesDeDiseno.Decorator.Interfaces;
using PatronesDeDiseno.Decorator.Abstract;

namespace PatronesDeDiseno.Decorator.Decorators
{
    public class MensajeConEmoji : MensajeDecorator
    {
        public MensajeConEmoji(IMensaje mensaje) : base(mensaje)
        {
        }

        public override void Enviar(string texto)
        {
            _mensaje.Enviar($"{texto} :)");
        }
    }
}
