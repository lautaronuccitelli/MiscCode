using System;
using System.Collections.Generic;
using PatronesDeDiseno.Adapter.Interfaces;
using PatronesDeDiseno.Adapter.Legacy;
using PatronesDeDiseno.Adapter.Adapters;
using PatronesDeDiseno.Adapter.Modern;

namespace PatronesDeDiseno.Adapter.Services
{
    public class SistemaImpresion
    {
        public void DemostrarPatron()
        {
            Console.WriteLine("=== DEMOSTRACION DEL PATRON ADAPTER ===");
            Console.WriteLine();

            Console.WriteLine("1. Creando impresora moderna (ya implementa IImpresora):");
            IImpresora impresoraModerna = new ImpresoraLaser();
            impresoraModerna.Imprimir("Documento moderno");
            
            Console.WriteLine();
            Console.WriteLine("2. Creando impresora vieja (necesita adaptador):");
            var impresoraVieja = new ImpresoraTermicaVieja();
            IImpresora adaptador = new AdaptadorTermica(impresoraVieja);
            adaptador.Imprimir("Ticket de venta");

            Console.WriteLine();
            Console.WriteLine("3. El cliente usa ambas impresoras de la misma manera:");
            
            var impresoras = new List<IImpresora>
            {
                impresoraModerna,
                adaptador
            };

            foreach (var impresora in impresoras)
            {
                Console.WriteLine("--- Imprimiendo con interfaz estandar ---");
                impresora.Imprimir("Texto estandarizado");
                Console.WriteLine();
            }

            Console.WriteLine("=== PATRON ADAPTER COMPLETADO ===");
        }
    }
}