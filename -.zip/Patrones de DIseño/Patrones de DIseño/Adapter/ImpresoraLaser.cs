using System;
using PatronesDeDiseno.Adapter.Interfaces;

namespace PatronesDeDiseno.Adapter.Modern
{
    public class ImpresoraLaser : IImpresora
    {
        public void Imprimir(string texto)
        {
            Console.WriteLine($"[IMPRESORA LASER MODERNA] Imprimiendo en alta calidad: {texto}");
        }
    }
}