using System;

namespace PatronesDeDiseno.Adapter.Legacy
{
    public class ImpresoraTermicaVieja
    {
        public void PrintTicket(string data)
        {
            Console.WriteLine($"[IMPRESORA TERMICA VIEJA] Imprimiendo: {data}");
        }
    }
}