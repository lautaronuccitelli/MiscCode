namespace PatronesDeDiseno.Adapter.Interfaces
{
    public interface IImpresora
    {
        void Imprimir(string texto);
    }
}