namespace PatronesDeDiseno.Decorator.Interfaces
{
    public interface IMensaje
    {
        void Enviar(string texto);
    }
}