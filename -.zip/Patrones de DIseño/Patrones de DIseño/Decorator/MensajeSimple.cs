using System;
using PatronesDeDiseno.Decorator.Interfaces;

namespace PatronesDeDiseno.Decorator.Base
{
    public class MensajeSimple : IMensaje
    {
        public void Enviar(string texto)
        {
            Console.WriteLine($"[MENSAJE SIMPLE] {texto}");
        }
    }
}