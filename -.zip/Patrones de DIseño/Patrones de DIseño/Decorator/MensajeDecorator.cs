using PatronesDeDiseno.Decorator.Interfaces;

namespace PatronesDeDiseno.Decorator.Abstract
{
    public abstract class MensajeDecorator : IMensaje
    {
        protected readonly IMensaje _mensaje;

        protected MensajeDecorator(IMensaje mensaje)
        {
            _mensaje = mensaje;
        }

        public virtual void Enviar(string texto)
        {
            _mensaje.Enviar(texto);
        }
    }
}