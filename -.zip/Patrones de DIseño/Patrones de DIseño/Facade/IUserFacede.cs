namespace PatronesDeDiseno.Facade.Interfaces
{
    public interface IUserFacade
    {
        bool RegistrarUsuario(string nombre, string email);
    }
}