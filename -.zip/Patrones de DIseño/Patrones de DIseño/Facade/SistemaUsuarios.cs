using System;
using PatronesDeDiseno.Facade.Interfaces;
using PatronesDeDiseno.Facade.Facades;

namespace PatronesDeDiseno.Facade.Services
{
    public class SistemaUsuarios
    {
        public void DemostrarPatron()
        {
            Console.WriteLine("=== DEMOSTRACION DEL PATRON FACADE ===");
            Console.WriteLine();

            IUserFacade userFacade = new UserFacade();

            Console.WriteLine("1. Registrando usuario con email valido:");
            userFacade.RegistrarUsuario("Juan Perez", "juan@email.com");

            Console.WriteLine();
            Console.WriteLine("========================================");
            Console.WriteLine();

            Console.WriteLine("2. Intentando registrar usuario con email invalido:");
            userFacade.RegistrarUsuario("Maria Lopez", "email_invalido");

            Console.WriteLine();
            Console.WriteLine("========================================");
            Console.WriteLine();

            Console.WriteLine("3. Registrando otro usuario valido:");
            userFacade.RegistrarUsuario("Carlos Rodriguez", "carlos@empresa.com");

            Console.WriteLine();
            Console.WriteLine("=== PATRON FACADE COMPLETADO ===");
            Console.WriteLine();
            Console.WriteLine("NOTA: La fachada oculta la complejidad de coordinar");
            Console.WriteLine("los 3 subsistemas (validacion, BD y email)");
        }
    }
}