using System;

namespace PatronesDeDiseno.Facade.Subsystems
{
    public class DBService
    {
        public bool GuardarUsuario(string nombre, string email)
        {
            Console.WriteLine($"[DB SERVICE] Conectando a base de datos...");
            Console.WriteLine($"[DB SERVICE] Guardando usuario: {nombre} - {email}");
            Console.WriteLine($"[DB SERVICE] Usuario guardado exitosamente en la BD");
            return true;
        }
    }
}