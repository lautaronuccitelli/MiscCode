using System;

namespace PatronesDeDiseno.Facade.Subsystems
{
    public class EmailValidator
    {
        public bool EsValido(string email)
        {
            Console.WriteLine($"[EMAIL VALIDATOR] Validando email: {email}");
            
            if (string.IsNullOrEmpty(email) || !email.Contains("@"))
            {
                Console.WriteLine($"[EMAIL VALIDATOR] Email invalido");
                return false;
            }
            
            Console.WriteLine($"[EMAIL VALIDATOR] Email valido");
            return true;
        }
    }
}