using System;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.GoogleMaps
{
    public class GoogleMapa : IMapa
    {
        public void Render(string ubicacion)
        {
            Console.WriteLine($"[Google Maps] Renderizando mapa de: {ubicacion}");
            Console.WriteLine("- Cargando tiles de Google...");
            Console.WriteLine("- Aplicando estilo de Google Maps...");
            Console.WriteLine("- Mapa de Google renderizado correctamente");
        }
    }
}