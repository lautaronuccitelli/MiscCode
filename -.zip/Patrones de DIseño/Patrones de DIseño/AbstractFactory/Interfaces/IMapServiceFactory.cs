namespace PatronesDeDiseno.AbstractFactory.Interfaces
{
    public interface IMapServiceFactory
    {
        IMapa CreateMap();
        IGeocoder CreateGeocoder();
    }
}