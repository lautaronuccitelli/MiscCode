namespace PatronesDeDiseno.AbstractFactory.Interfaces
{
    public interface IMapa
    {
        void Render(string ubicacion);
    }
}