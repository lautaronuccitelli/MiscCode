namespace PatronesDeDiseno.AbstractFactory.Interfaces
{
    public interface IGeocoder
    {
        void Buscar(string direccion);
    }
}