using System;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.Services
{
    public class Navegador
    {
        private readonly IMapa _mapa;
        private readonly IGeocoder _geocoder;

        public Navegador(IMapServiceFactory factory)
        {
            _mapa = factory.CreateMap();
            _geocoder = factory.CreateGeocoder();
        }

        public void Run(string ubicacion, string textoDireccion)
        {
            Console.WriteLine("=== INICIANDO NAVEGACIÓN ===");
            _mapa.Render(ubicacion);
            Console.WriteLine();
            _geocoder.Buscar(textoDireccion);
            Console.WriteLine("=== NAVEGACIÓN COMPLETADA ===");
        }
    }
}