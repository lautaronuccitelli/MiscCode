using System;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.OpenStreetMap
{
    public class OpenStreetMapa : IMapa
    {
        public void Render(string ubicacion)
        {
            Console.WriteLine($"[OpenStreetMap] Renderizando mapa de: {ubicacion}");
            Console.WriteLine("- Cargando datos de OSM...");
            Console.WriteLine("- Aplicando estilo libre de OSM...");
            Console.WriteLine("- Mapa de OpenStreetMap renderizado correctamente ✓");
        }
    }
}