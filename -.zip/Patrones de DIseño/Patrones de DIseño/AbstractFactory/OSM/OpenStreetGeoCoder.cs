using System;
using PatronesDeDiseno.AbstractFactory.Interfaces;

namespace PatronesDeDiseno.AbstractFactory.OpenStreetMap
{
    public class OpenStreetGeocoder : IGeocoder
    {
        public void Buscar(string direccion)
        {
            Console.WriteLine($"[Nominatim OSM] Buscando dirección: {direccion}");
            Console.WriteLine("- Conectando a Nominatim API...");
            Console.WriteLine("- Procesando con datos abiertos...");
            Console.WriteLine($"- Resultado: Lat: -38.0056, Lng: -57.5427 (OSM) ✓");
        }
    }
}