﻿using System;
using PatronesDeDiseno.Singleton;
using PatronesDeDiseno.Builder.Interfaces;
using PatronesDeDiseno.Builder.Models;
using PatronesDeDiseno.Builder.Builders;
using PatronesDeDiseno.Builder.Services;
using PatronesDeDiseno.AbstractFactory.Interfaces;
using PatronesDeDiseno.AbstractFactory.GoogleMaps;
using PatronesDeDiseno.AbstractFactory.OpenStreetMap;
using PatronesDeDiseno.AbstractFactory.Services;
using PatronesDeDiseno.Adapter.Services;
using PatronesDeDiseno.Decorator.Services;
using PatronesDeDiseno.Facade.Services;

namespace PatronesDeDiseno
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcion = 0;
            while (opcion != 7)
            {
                Console.Clear();
                Console.WriteLine("=== PATRONES DE DISENO ===");
                Console.WriteLine("1) SINGLETON - Logger");
                Console.WriteLine("2) BUILDER - Construccion de Hamburguesas");
                Console.WriteLine("3) ABSTRACT FACTORY - Navegador de Mapas");
                Console.WriteLine("4) ADAPTER - Sistema de Impresion");
                Console.WriteLine("5) DECORATOR - Sistema de Mensajeria");
                Console.WriteLine("6) FACADE - Gestion de Usuarios");
                Console.WriteLine("7) SALIR");
                Console.Write("Elige una opcion (1-7): ");

                if (int.TryParse(Console.ReadLine(), out opcion))
                {
                    switch (opcion)
                    {
                        case 1:
                            EjecutarSingleton();
                            break;
                        case 2:
                            EjecutarBuilder();
                            break;
                        case 3:
                            EjecutarAbstractFactory();
                            break;
                        case 4:
                            EjecutarAdapter();
                            break;
                        case 5:
                            EjecutarDecorator();
                            break;
                        case 6:
                            EjecutarFacade();
                            break;
                        case 7:
                            Console.WriteLine("Hasta luego!");
                            return;
                        default:
                            Console.WriteLine("Opcion invalida. Presiona cualquier tecla para continuar...");
                            Console.ReadKey();
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Por favor ingresa un numero valido.");
                    Console.ReadKey();
                }
            }
        }

        #region SINGLETON - LOGGER
        static void EjecutarSingleton()
        {
            Console.Clear();
            Console.WriteLine("=== PRUEBA DEL LOGGER SINGLETON ===");

            var a = Logger.Instancia;
            Console.WriteLine("Primera referencia obtenida (variable 'a')");

            a.Info("Aplicacion iniciada");
            a.Info("Usuario logueado correctamente");
            a.Info("Procesando datos importantes");
            a.Info("Operacion completada exitosamente");

            Console.WriteLine($"Total de mensajes registrados: {a.TotalMensajes}");

            var b = Logger.Instancia;
            Console.WriteLine("Segunda referencia obtenida (variable 'b')");

            b.Info("Nuevo proceso iniciado");
            b.Info("Guardando configuracion");

            b.Dump();

            bool sonElMismoObjeto = ReferenceEquals(a, b);
            Console.WriteLine($"Las variables 'a' y 'b' referencian al mismo objeto: {sonElMismoObjeto}");
            Console.WriteLine($"Hash de 'a': {a.GetHashCode()}");
            Console.WriteLine($"Hash de 'b': {b.GetHashCode()}");

            Console.WriteLine("=== PRUEBA DESDE METODOS SEPARADOS ===");
            PruebaDesdeMetodo1();
            PruebaDesdeMetodo2();

            Logger.Instancia.Dump();

            Console.WriteLine("Presiona cualquier tecla para volver al menu principal...");
            Console.ReadKey();
        }

        static void PruebaDesdeMetodo1()
        {
            Logger.Instancia.Info("Mensaje desde Metodo1");
        }

        static void PruebaDesdeMetodo2()
        {
            Logger.Instancia.Info("Mensaje desde Metodo2");
        }
        #endregion

        #region BUILDER - HAMBURGUESAS
        static void EjecutarBuilder()
        {
            int opcionBuilder = 0;
            while (opcionBuilder != 5)
            {
                Console.Clear();
                Console.WriteLine("=== CONSTRUCCION DE HAMBURGUESAS (BUILDER) ===");
                Console.WriteLine("1) HAMBURGUESA CLASICA (usando Cocinero)");
                Console.WriteLine("2) HAMBURGUESA DOBLE CHEDDAR (usando Cocinero)");
                Console.WriteLine("3) HACER HAMBURGUESA PERSONALIZADA (manual)");
                Console.WriteLine("4) INTENTAR CREAR UNA INCOMPLETA (para ver excepcion)");
                Console.WriteLine("5) VOLVER AL MENU PRINCIPAL");
                Console.Write("Elige una opcion (1-5): ");

                if (int.TryParse(Console.ReadLine(), out opcionBuilder))
                {
                    switch (opcionBuilder)
                    {
                        case 1:
                            CrearConReceta("Clasica", b => Cocinero.Clasica(b));
                            break;
                        case 2:
                            CrearConReceta("Doble Cheddar", b => Cocinero.DobleCheddar(b));
                            break;
                        case 3:
                            CrearManual();
                            break;
                        case 4:
                            IntentarIncompleta();
                            break;
                        case 5:
                            return;
                        default:
                            Console.WriteLine("Opcion invalida. Presiona una tecla para continuar...");
                            Console.ReadKey();
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Por favor ingresa un numero valido.");
                    Console.ReadKey();
                }
            }
        }

        static void CrearConReceta(string nombre, Func<IHamburguesaBuilder, Hamburguesa> receta)
        {
            var builder = new HamburguesaClasicaBuilder();
            try
            {
                Console.WriteLine();
                Console.WriteLine($"--- Creando: {nombre} ---");
                var h = receta(builder);
                Console.WriteLine(h);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"ERROR: {ex.Message}");
            }

            Console.WriteLine("Presiona cualquier tecla para volver al menu...");
            Console.ReadKey();
        }

        static void CrearManual()
        {
            var builder = new HamburguesaClasicaBuilder();
            Console.WriteLine();
            Console.WriteLine("--- Hamburguesa personalizada ---");

            Console.Write("Pan (ej: Pan integral): ");
            var pan = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(pan)) builder.ConPan(pan);

            Console.Write("Carne (ej: Pollo / Vacuna): ");
            var carne = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(carne)) builder.ConCarne(carne);

            if (AskYesNo("Queso? (s/n): ")) builder.ConQueso();
            else builder.ConQueso(false);

            if (AskYesNo("Lechuga? (s/n): ")) builder.ConLechuga();
            if (AskYesNo("Tomate? (s/n): ")) builder.ConTomate();
            if (AskYesNo("Cebolla? (s/n): ")) builder.ConCebolla();

            Console.Write("Salsa (enter para nada): ");
            var salsa = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(salsa)) builder.ConSalsa(salsa);

            try
            {
                var h = builder.Build();
                Console.WriteLine();
                Console.WriteLine("--- Resultado ---");
                Console.WriteLine(h);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"ERROR: {ex.Message}");
            }

            Console.WriteLine("Presiona cualquier tecla para volver al menu...");
            Console.ReadKey();
        }

        static void IntentarIncompleta()
        {
            var builder = new HamburguesaClasicaBuilder();
            Console.WriteLine();
            Console.WriteLine("--- Intento de hamburguesa incompleta (solo pan) ---");
            builder.ConPan("Pan comun");
            try
            {
                var h = builder.Build();
                Console.WriteLine(h);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"ERROR: {ex.Message}");
            }

            Console.WriteLine("Presiona cualquier tecla para volver al menu...");
            Console.ReadKey();
        }

        static bool AskYesNo(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                var r = Console.ReadLine()?.Trim().ToLower();
                if (string.IsNullOrEmpty(r)) return false;
                if (r == "s" || r == "si" || r == "y" || r == "yes") return true;
                if (r == "n" || r == "no") return false;
                Console.WriteLine("Respuesta no valida. Responde 's' o 'n'.");
            }
        }
        #endregion

        #region ABSTRACT FACTORY - NAVEGADOR
        static void EjecutarAbstractFactory()
        {
            Console.Clear();
            Console.WriteLine("=== NAVEGADOR DE MAPAS (ABSTRACT FACTORY) ===");
            Console.WriteLine("1) Usar Google Maps");
            Console.WriteLine("2) Usar OpenStreetMap");
            Console.Write("Elige el proveedor de mapas (1-2): ");

            if (int.TryParse(Console.ReadLine(), out int opcion))
            {
                IMapServiceFactory factory = null;
                
                switch (opcion)
                {
                    case 1:
                        factory = new GoogleMapServicesFactory();
                        Console.WriteLine("Has seleccionado Google Maps");
                        break;
                    case 2:
                        factory = new OpenStreetMapServicesFactory();
                        Console.WriteLine("Has seleccionado OpenStreetMap");
                        break;
                    default:
                        Console.WriteLine("Opcion invalida, usando Google Maps por defecto");
                        factory = new GoogleMapServicesFactory();
                        break;
                }

                Console.Write("Ingresa la ubicacion a mostrar: ");
                var ubicacion = Console.ReadLine() ?? "Buenos Aires";

                Console.Write("Ingresa la direccion a buscar: ");
                var direccion = Console.ReadLine() ?? "Av. Corrientes 1000";

                var navegador = new Navegador(factory);
                Console.WriteLine();
                Console.WriteLine("=== EJECUTANDO NAVEGADOR ===");
                navegador.Run(ubicacion, direccion);
            }
            else
            {
                Console.WriteLine("Entrada invalida, usando configuracion por defecto");
                var factory = new GoogleMapServicesFactory();
                var navegador = new Navegador(factory);
                navegador.Run("Mar del Plata", "Plaza San Martin");
            }

            Console.WriteLine("Presiona cualquier tecla para volver al menu principal...");
            Console.ReadKey();
        }
        #endregion

        #region ADAPTER - IMPRESION
        static void EjecutarAdapter()
        {
            Console.Clear();
            Console.WriteLine("=== SISTEMA DE IMPRESION (ADAPTER) ===");
            
            var sistema = new SistemaImpresion();
            sistema.DemostrarPatron();

            Console.WriteLine("Presiona cualquier tecla para volver al menu principal...");
            Console.ReadKey();
        }
        #endregion

        #region DECORATOR - MENSAJERIA
        static void EjecutarDecorator()
        {
            Console.Clear();
            Console.WriteLine("=== SISTEMA DE MENSAJERIA (DECORATOR) ===");
            
            var sistema = new SistemaMensajeria();
            sistema.DemostrarPatron();

            Console.WriteLine("Presiona cualquier tecla para volver al menu principal...");
            Console.ReadKey();
        }
        #endregion

        #region FACADE - USUARIOS
        static void EjecutarFacade()
        {
            Console.Clear();
            Console.WriteLine("=== GESTION DE USUARIOS (FACADE) ===");
            
            var sistema = new SistemaUsuarios();
            sistema.DemostrarPatron();

            Console.WriteLine("Presiona cualquier tecla para volver al menu principal...");
            Console.ReadKey();
        }
        #endregion
    }
}