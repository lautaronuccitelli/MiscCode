package proyecto;

public class Product {

    private String name;
    private float price;
    private int code;
    private String brand;

    public String getName() {
        return this.name;
    }

    public void setName(String newName) {
        this.name = newName;
    }

    public float getPrice() {
        return this.price;
    }

    public void setPrice(float newPrice) {
        this.price = newPrice;
    }

    public int getCode() {
        return this.code;
    }

    public void setCode(int newCode) {
        this.code = newCode;
    }

    public String getBrand() {
        return this.brand;
    }

    public void setBrand(String newBrand) {
        this.brand = newBrand;
    }
}
